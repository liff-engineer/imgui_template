
    - name: Setup interactive tmate session
      uses: mxschmitt/action-tmate@v2
