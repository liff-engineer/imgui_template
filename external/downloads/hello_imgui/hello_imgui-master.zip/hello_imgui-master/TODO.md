# Main
* [ ] SDL_GL_CreateContext fail with safari / emscripten

# Misc
* [ ] Add issue / qtimgui on Windows (blank window)

# Doc
* [ ] doc / hello_imgui_add_app ?

# Features
* [ ] External docking window ?

# Platforms
## iOS
## Emscripten
## Windows
## OSX
* [ ] Make app package / embed assets ?
## Android

   
