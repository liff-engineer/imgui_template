In order to customize your application
icons and launch image, copy this "ios" folder
into the folder where your aplication's CMakeLists
resides, and replace by your own images !

Note: 
- If you want to support the iPhone X full resolution,
rename Default-375w-812h@3x.disabled.png to Default-375w-812h@3x.png
(Note however, that with iPhone X the screen has black
zones in the upper and lower zones).

