Note: the icon mipmap-source/ic_launcher.png
was used to generate all the variations inside res/

See [tools/android/resize_icons.py](../../../../../tools/android/resize_icons.py)

