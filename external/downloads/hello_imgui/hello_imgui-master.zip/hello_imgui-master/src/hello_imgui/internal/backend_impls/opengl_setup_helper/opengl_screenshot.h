#pragma once

#include "hello_imgui/hello_imgui_screenshot.h"


namespace HelloImGui
{
    ImageBuffer OpenglScreenshotRgb();
}