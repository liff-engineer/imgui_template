#pragma once
#include <string>

std::string getAppleBundleResourcePath(const std::string & filename);
