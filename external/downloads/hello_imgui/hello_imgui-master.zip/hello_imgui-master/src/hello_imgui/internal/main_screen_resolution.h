#pragma once
#include "imgui.h"
#include <array>
std::array<int, 2> MainScreenResolution();
ImVec2 MainScreenResolution_Vec2();