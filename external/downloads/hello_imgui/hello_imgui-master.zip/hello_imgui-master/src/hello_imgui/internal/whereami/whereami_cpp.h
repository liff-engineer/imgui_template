#pragma once

#include <string>

std::string wai_getExecutablePath_string();
std::string wai_getExecutableFolder_string();

std::string wai_getModulePath_string();
