#include "hello_imgui/internal/imgui_global_context.h"

#ifdef HELLO_IMGUI_IMGUI_SHARED
ImGuiContext*   GImGui = NULL;
#endif
