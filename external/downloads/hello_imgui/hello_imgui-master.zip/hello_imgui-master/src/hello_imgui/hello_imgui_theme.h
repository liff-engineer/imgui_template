#pragma once
#include "hello_imgui/imgui_theme.h"

namespace HelloImGui
{
    void Theme_WindowGui(ImGuiTheme::ImGuiTweakedTheme& tweakedTheme);
    void Theme_MenuGui(ImGuiTheme::ImGuiTweakedTheme& tweakedTheme);
}